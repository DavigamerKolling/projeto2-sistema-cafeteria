document.getElementById("form-venda").addEventListener("submit", function (e) {
    e.preventDefault();
  
    const cliente = document.getElementById("cliente").value.trim();
    const data = document.getElementById("data").value;
    const valor = parseFloat(document.getElementById("valor").value);
    const pagamento = document.getElementById("pagamento").value;
  
    if (!cliente || !data || isNaN(valor) || !pagamento) {
      alert("Preencha todos os campos corretamente.");
      return;
    }
  
    const novaVenda = { cliente, data, valor, pagamento };
  
    // Armazenar no localStorage (simples)
    const vendas = JSON.parse(localStorage.getItem("vendas")) || [];
    vendas.push(novaVenda);
    localStorage.setItem("vendas", JSON.stringify(vendas));
  
    alert("Venda registrada com sucesso!");
    window.location.href = "Vendas.html";
  });
  
  function voltarParaVendas() {
    window.location.href = "Vendas.html";
  }  
  