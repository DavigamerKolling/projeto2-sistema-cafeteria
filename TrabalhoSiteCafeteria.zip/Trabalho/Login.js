document.getElementById("login-form").addEventListener("submit", function (event) {
  event.preventDefault();

  const usuario = document.getElementById("usuario").value.trim();
  const senha = document.getElementById("senha").value;

  if (!usuario || !senha) {
    alert("Preencha todos os campos para continuar.");
    return;
  }

  // Armazena os dados de login na sessão
  sessionStorage.setItem("usuarioLogado", usuario);
  sessionStorage.setItem("senhaLogada", senha); // Se necessário

  // Redireciona para a página inicial
  window.location.href = "Home.html";
});