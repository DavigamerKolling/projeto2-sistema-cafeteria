const tabela = document.getElementById("corpo-tabela");
const busca = document.getElementById("busca");
const filtro = document.getElementById("filtro");

let itens = JSON.parse(localStorage.getItem("itensCadastrados")) || [];

function renderizarItens(lista) {
  tabela.innerHTML = "";

  if (lista.length === 0) {
    tabela.innerHTML = '<tr><td colspan="4">Nenhum item encontrado.</td></tr>';
    return;
  }

  lista.forEach(item => {
    const tr = document.createElement("tr");

    tr.innerHTML = `
      <td>${item.nome}</td>
      <td>${item.tipo}</td>
      <td>R$ ${parseFloat(item.preco).toFixed(2)}</td>
      <td><button class="ver-detalhes">Detalhes</button></td>
    `;

    tabela.appendChild(tr);
  });
}

function filtrarItens() {
  const termo = busca.value.toLowerCase();
  const tipoFiltro = filtro.value;

  const resultado = itens.filter(item => {
    const nomeOK = item.nome.toLowerCase().includes(termo);
    const tipoOK = tipoFiltro === "" || item.tipo === tipoFiltro;
    return nomeOK && tipoOK;
  });

  renderizarItens(resultado);
}

function novoCadastro() {
  window.location.href = "NovoCadastro.html";
}

busca.addEventListener("input", filtrarItens);
filtro.addEventListener("change", filtrarItens);

renderizarItens(itens);

function voltarParaHome() {
  window.location.href = "Home.html";
}
