const usuario = sessionStorage.getItem("usuarioLogado");
const info = document.getElementById("info-usuario");

if (!usuario) {
  alert("Você precisa fazer login.");
  window.location.href = "Login.html";
} else {
  info.textContent = `Usuário logado: ${usuario}`;
}

function voltarParaLogin() {
  window.location.href = "Login.html";
}
