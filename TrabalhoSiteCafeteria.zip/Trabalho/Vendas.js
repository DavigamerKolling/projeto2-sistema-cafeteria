const tabela = document.getElementById("corpo-tabela");
const busca = document.getElementById("busca");
const filtro = document.getElementById("filtro");

let vendas = JSON.parse(localStorage.getItem("vendas")) || [];

function renderizarVendas(lista) {
  tabela.innerHTML = "";

  if (lista.length === 0) {
    tabela.innerHTML = '<tr><td colspan="5">Nenhuma venda encontrada.</td></tr>';
    return;
  }

  lista.forEach(venda => {
    const tr = document.createElement("tr");

    tr.innerHTML = `
      <td>${venda.cliente}</td>
      <td>${venda.data}</td>
      <td>R$ ${parseFloat(venda.valor).toFixed(2)}</td>
      <td>${venda.pagamento}</td>
      <td><button class="ver-detalhes">Detalhes</button></td>
    `;

    tabela.appendChild(tr);
  });
}

function filtrarVendas() {
  const termo = busca.value.toLowerCase();
  const tipo = filtro.value;

  const resultado = vendas.filter(venda => {
    const clienteOK = venda.cliente.toLowerCase().includes(termo);
    const filtroOK = tipo === "" || venda.pagamento === tipo;
    return clienteOK && filtroOK;
  });

  renderizarVendas(resultado);
}

// Eventos
busca.addEventListener("input", filtrarVendas);
filtro.addEventListener("change", filtrarVendas);

renderizarVendas(vendas);

function voltarParaHome() {
  window.location.href = "Home.html";
}

