const form = document.getElementById("form-cadastro");

form.addEventListener("submit", function (event) {
  event.preventDefault();

  const nome = document.getElementById("nome").value.trim();
  const tipo = document.getElementById("tipo").value;
  const preco = document.getElementById("preco").value;

  if (!nome || !tipo || !preco) {
    alert("Preencha todos os campos!");
    return;
  }

  const novoItem = { nome, tipo, preco };

  const itens = JSON.parse(localStorage.getItem("itensCadastrados")) || [];
  itens.push(novoItem);
  localStorage.setItem("itensCadastrados", JSON.stringify(itens));

  alert("Item cadastrado com sucesso!");
  window.location.href = "Cadastro.html";
});

function voltar() {
  window.location.href = "Cadastro.html";
}

function voltarParaCadastro() {
  window.location.href = "Cadastro.html";
}
